// Usage: https://www.chartjs.org/
import Chart from "chart.js";

window.Chart = Chart;