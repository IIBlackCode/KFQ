class Date2021_06_22 :
    def no_01(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/01_basic.html', context)

    def no_02(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/02_operator.html', context)

    def no_03(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/03_ajax.html', context)


    def no_04(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/04.html', context) 

    def no_05(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/05.html', context) 
    
    def no_06(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/06.html', context) 
    
    def no_07(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/07.html', context) 

    def no_08(request):
        page ='2021-06-22'
        print("Date :",page)
        context = {
            'page' : page
        }
        return render(request, './2021-06-22/08.html', context)