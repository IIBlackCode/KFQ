class UserStorage {
    loginUser(id, password) {
        return new Promise((resolve, reject) => {

            setTimeout(() => {
                if ((id === 'java' && password === 'script') ||
                    (id === 'call' && password === 'back')) {
                    resolve(id);
                } else {
                    reject(new Error('not found'));
                }
            }, 1000);
        });
    }
    getRoles(id) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (id === 'java') {
                    resolve({ id: 'java', role: 'admin' });
                } else if (id === 'call') {
                    resolve({ id: 'call', role: 'manager' });
                } else {
                    reject(new Error('no access'));
                }
            }, 1000);
        });
    }
}


const userStorage = new UserStorage();
const id = 'java';
const password = 'script';
userStorage.loginUser(id, password)
    .then(id => userStorage.getRoles(id))
    .then(user =>
        alert(`Hello ${user.id},
you have a ${user.role}`))
    .catch(result => console.log(result));