const array = [];
array[0] = 'A';
array[100] = 'A100';
array['키'] = '값';
console.log(array.length)
console.log(array['키'])