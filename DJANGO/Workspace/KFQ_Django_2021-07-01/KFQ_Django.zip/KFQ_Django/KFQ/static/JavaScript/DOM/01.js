
const h1 = (text) => `<h1>${text}</h1>`;
document.body.innerHTML += h1('1번째 script 태그');
document.body.innerHTML += h1('2번째 script 태그');
document.body.innerHTML += h1('3번째 script 태그');