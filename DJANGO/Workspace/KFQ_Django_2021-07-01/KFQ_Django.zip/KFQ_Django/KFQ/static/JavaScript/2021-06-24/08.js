document.querySelector('a')
    .addEventListener('click', (e) => {
        e.preventDefault();
        alert('click');
    })