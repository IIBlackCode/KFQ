from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Member
from django.utils import timezone

def join(request):
    if request.method == 'GET':
        return render(request, 'member/join.html', {})
    else:
        user_id = request.POST['user_id']
        user_pw = request.POST['user_pw']
        user_name = request.POST['user_name']

        m = Member(
            user_id=user_id, user_pw=user_pw,
            user_name=user_name)
        m.c_date = timezone.now()
        m.save()
        # return render(
        #     request, 'member/join.html', {
        #         'user_id':user_id,
        #         'is_visit': True
        #     }
        # )
        return HttpResponse('가입 완료' + user_id + user_pw + user_name)

def login(request):
    if request.method == 'GET':
        return render(request, 'member/login.html', {})
    else:
        user_id = request.POST['user_id']
        user_pw = request.POST['user_pw']

        try:
            member = \
                Member.objects.get(
                    user_id=user_id, user_pw=user_pw)
        except:
            return HttpResponse('로그인 실패')
        else:
            # 세션에 로그인 관련 정보 저장
            request.session['user_id'] = user_id
            
            a = request.session['user_id']

            # del request.session['user_id']
            # request.session.flush()

            return HttpResponse('로그인 성공')
        
def logout(request):
    del request.session['user_id']
    return redirect('/login/')

import glob
def upload1(request):
    if request.method == 'POST':
        upload_file = request.FILES.get('my_file')
        # 6월1일(화) 일정안내.pptx
        # 6월1일(화) 일정안내_1424157784.pptx
        
        name = upload_file.name
        size = upload_file.size

        f_list = glob.glob('*')
        print(f_list)
        if name in f_list:  # 존재하는 파일
            print('존재하고 있음')

        with open('static/%s' % name, 'wb') as file:
            for chunk in upload_file.chunks():
                file.write(chunk)
        return HttpResponse('%s<br>%s' % (name, size))
    return render(request, 'upload1.html', {})

import os
# import config.settings
from config import settings
def download(request):
    # c:/dev/django/mysite/db.sqlite3
    filepath = os.path.join(
        settings.BASE_DIR, 'db.sqlite3')

    filename = filepath.split('/')[-1]
    filename = os.path.basename(filepath)


    with open(filepath, 'rb') as f:
        response = HttpResponse(
        f, content_type='application/octet-stream')
        response['Content-Disposition'] = \
        'attachment; filename="{}"'.format(filename)
        return response

