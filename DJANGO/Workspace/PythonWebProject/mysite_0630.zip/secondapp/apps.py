from django.apps import AppConfig


class SecondappConfig(AppConfig):
    name = 'secondapp'
