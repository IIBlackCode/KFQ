from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.http import StreamingHttpResponse
from django.views.decorators import gzip
import cv2
import threading
from PIL import Image
import numpy as np
from mtcnn import MTCNN
import pickle
import os
import sqlite3
import datetime
from pytz import timezone
import time
import collections

# import gzip
# Create your views here.

def home(request) :
    return render(request, 'home.html')

def default(request) :
    cam.camoff()
    return render(request, 'default.html')


### 동작 함수
detector, sex_model, age_model = None, None, None

def rgb2gray(rgb):
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
    return gray

def model_load() :
    global detector
    global sex_model
    global age_model

    ## load face detector
    detector = MTCNN()

    ## load the model
    print('Model load...')
    sex_model = pickle.load(open('C:/Users/K/Desktop/pj/sex-model-final.pkl', 'rb'))
    age_model = pickle.load(open('C:/Users/K/Desktop/pj/age-model-final.pkl', 'rb'))
    print('Loading Finished!')

def detect_face(img):
    
    mt_res = detector.detect_faces(img)     ## MTCNN.detect_faces
    return_res = []
    
    for face in mt_res:
        x, y, width, height = face['box']
        center = [x+(width/2), y+(height/2)]
        max_border = max(width, height)
        
        ## center alignment
        left = max(int(center[0]-(max_border/2)), 0)
        right = max(int(center[0]+(max_border/2)), 0)
        top = max(int(center[1]-(max_border/2)), 0)
        bottom = max(int(center[1]+(max_border/2)), 0)
        
        ## crop the face
        center_img_k = img[top:top+max_border, left:left+max_border, :]
        center_img = np.array(Image.fromarray(center_img_k).resize([224, 224]))
        
        ## predictions
        sex_preds = sex_model.predict(center_img.reshape(1,224,224,3))[0][0]
        age_preds = age_model.predict(center_img.reshape(1,224,224,3))[0][0]
        
        return_res.append([top, right, bottom, left, sex_preds, age_preds])
        
    return return_res

### 카메라    
class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        (self.grabbed, self.frame) = self.video.read()
        threading.Thread(target=self.get_frame, args=()).start()

    def __del__(self):
        self.video.release()

    def get_frame(self):
        self.grabbed, self.frame = self.video.read()

        if not self.grabbed : return redirect('default.html')

        image = self.frame
        rgb_frame = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        face_locations = detect_face(rgb_frame)

        for top, right, bottom, left, sex_preds, age_preds in face_locations:
            cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 2)
            sex_text = 'Female' if sex_preds > 0.5 else 'Male'
            cv2.putText(image, 'Sex: {}({:.3f})'.format(sex_text, sex_preds), (left, top-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (36,255,12), 1)
            cv2.putText(image, 'Age: {:.3f}'.format(age_preds), (left, top-25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (36,255,12), 1)
        cv2.rectangle(image, (50,50), (150, 150), (255,255,255), 3)

        _, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes()

    def update(self):
        while True:
            (self.grabbed, self.frame) = self.video.read()
    
    def camoff(self) :
        print('cam off')
        self.video.release()

def gen(camera):
    while True:
        frame = camera.get_frame()
        yield(b'--frame\r\n'
              b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

cam = None
@gzip.gzip_page
def livecam(request):
    global cam
    
    if detector == None or sex_model == None or age_model == None :
        model_load()

    print(type(detector), type(sex_model), type(age_model))
    try:
        cam = VideoCamera()
        return StreamingHttpResponse(gen(cam), content_type="multipart/x-mixed-replace;boundary=frame")
    except:  # This is bad! replace it with proper handling
        print('error')
        pass