from django.db import models

# Create your models here.
class Pedestrian(models.Model) :
    played_AD = models.IntegerField()
    time = models.CharField(max_length=30)

class Client(models.Model) :
    client_ID = models.CharField(max_length=30)
    price_1s = models.IntegerField()
    target_group = models.IntegerField()
    AD_length = models.IntegerField()

class Indicator(models.Model) :
    client_ID = models.CharField(max_length=200)
    date = models.CharField(max_length=30)
    ad_play_cnt = models.IntegerField()
    ad_play_time = models.IntegerField()

    major_group = models.CharField(max_length=30)