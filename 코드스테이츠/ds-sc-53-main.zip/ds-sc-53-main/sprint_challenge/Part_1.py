# SHA(Secure Hash Algorithm) : 고정값을 반환하는 함수로 Hashing 적용
# sha256개념을 이해하는 것이 아닌 결과값을 반환해주는 적절한 메소드를 활용하세요.

import hashlib

def sha_hash_function():
  h = # hashlib 모듈관련 메소드 
  pass


if __name__ == '__main__':
    sha_hash_function()
