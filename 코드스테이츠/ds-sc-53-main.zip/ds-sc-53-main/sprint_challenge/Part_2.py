# 아래 함수를 구현하자.
def graph_algorithm(graph, start):
    
    node_list = list(graph) 
    node_list.remove(start)
        
    visit_node = [start]
    path_list = []
    next_node = None

    while node_list:
        distance_of_node = 10
        for start_index in visit_node:
            for distance_index in graph[start_index]:
                    ##### 소스코드 작성 #####

    return path_list

if __name__ == '__main__':
    weighted_graph = {  
        "s1":{"s1": 0, "s2": 2, "s10": 3, "s12": 4, "s5":3},
        "s2":{"s1": 1, "s2": 0, "s10": 2, "s12": 2, "s5":2},
        "s10":{"s1": 2, "s2": 6, "s10": 0, "s12":3, "s5":4},
        "s12":{"s1": 3, "s2": 5, "s10": 2, "s12":0,"s5":2},
        "s5":{"s1": 3, "s2": 5, "s10": 2, "s12":4,"s5":0},
    }

    path_list2 = graph_algorithm(weighted_graph, 's1')
    print(path_list2)
