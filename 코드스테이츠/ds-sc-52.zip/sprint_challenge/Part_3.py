# 3) 2개의 문장을 입력받고, 두 문장을 비교하여 '입력받은 두번째 문장에 추가된 단어'를 찾는 코드를 구현하세요.
# 단어는 공백을 기준으로 구분됩니다. 공백이 2개 이상 같이 있는 경우는 고려하지 않습니다
# 참조개념 : 딕셔너리의 키에 따른 값 개념

# 예시입출력값
    # 1) 정상적으로 반환되는 경우
    # 첫번째 문장입력 : the best
    # 두번째 문장입력 : the best is
    # 추가된 단어 :  is
    
    # 2) 첫번째 문장에 추가된 단어는 알 수 없다.('None' 은 알 수 없음을 의미)
    # 첫번째 문장입력 : the best is
    # 두번째 문장입력 : the best
    # 추가된 단어 :  None

ANSWER = 'wrong answer'
CONSTANT = 'O(1)'
LOGARITHMIC = 'O(logn)'
LINEAR = 'O(n)'
LINEARITHMIC = 'O(nlogn)'
QUADRATIC = 'O(n^2)'
EXPONENTIAL = 'O(c^n)' 

def added_word():
    ##### 코드를 작성해주세요 #####
    pass #### 문제 풀 때는 pass를 지워주세요 ####


def added_word_time_complexity():
    return ANSWER # 답안을 작성해주세요.

if __name__ == '__main__':
    "첫번째 문장입력 : "
    "두번째 문장입력 : "
    "추가된 단어 : "
