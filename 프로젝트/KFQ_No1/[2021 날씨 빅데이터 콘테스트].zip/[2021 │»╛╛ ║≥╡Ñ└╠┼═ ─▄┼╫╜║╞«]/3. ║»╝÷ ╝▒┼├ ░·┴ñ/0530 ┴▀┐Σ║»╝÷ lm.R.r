######################################## ����û����
setwd('C:/weather')
rm(list=ls())

data <- read.csv('����û����final.csv')
#data$date <- as.Date(data$date)
data$sex <- as.factor(data$sex)
data$age <- as.factor(data$age)
data$weekday <- as.factor(data$weekday)
#data$month <- as.factor(data$month)
data$season <- as.factor(data$season)
str(data)

data <- data[c(-1,-13)]
str(data)

set.seed(1)
idx<-createDataPartition(data$total_qty, p=0.7, list=F)

air_train<-data[idx, ]
air_test<-data[-idx, ]

datalm <- lm(total_qty  ~ ., data = air_train)
summary(datalm)

pred_lm = predict(datalm, newdata = air_test)

test_y = air_test[, 3]

#���� : MSE, MAE, RMSE
lm_mse = mean((exp(test_y) - exp(pred_lm))^2)
lm_mae = caret::MAE(exp(test_y), exp(pred_lm))
lm_rmse = caret::RMSE(exp(test_y), exp(pred_lm))
summary(datalm)
#��� : R-squared, MSE, MAE, RMSE
cat(lm_rmse, lm_mae, lm_mse)

######################################## ������

#setwd('C:/weather')
rm(list=ls())

data <- read.csv('������final.csv')
#data$date <- as.Date(data$date)
data$sex <- as.factor(data$sex)
data$age <- as.factor(data$age)
data$weekday <- as.factor(data$weekday)
#data$month <- as.factor(data$month)
#data$season <- as.factor(data$season)
str(data)
data <- data[c(-1,-6,-14)]

set.seed(1)
idx<-createDataPartition(data$total_qty, p=0.7, list=F)

air_train<-data[idx, ]
air_test<-data[-idx, ]

datalm <- lm(total_qty  ~ ., data = air_train)
#summary(datalm)

pred_lm = predict(datalm, newdata = air_test)

test_y = air_test[, 3]

#���� : MSE, MAE, RMSE
lm_mse = mean((exp(test_y) - exp(pred_lm))^2)
lm_mae = caret::MAE(exp(test_y), exp(pred_lm))
lm_rmse = caret::RMSE(exp(test_y), exp(pred_lm))

#��� : R-squared, MSE, MAE, RMSE
cat(lm_rmse, lm_mae, lm_mse)
summary(datalm)

######################################## ������


rm(list=ls())

data <- read.csv('������final.csv')
#data$date <- as.Date(data$date)
data$sex <- as.factor(data$sex)
data$age <- as.factor(data$age)
data$weekday <- as.factor(data$weekday)
#data$month <- as.factor(data$month)
#data$season <- as.factor(data$season)
str(data)
data <- data[c(-1,-15)]
View(data)

set.seed(1)
idx<-createDataPartition(data$total_qty, p=0.7, list=F)

air_train<-data[idx, ]
air_test<-data[-idx, ]

datalm <- lm(total_qty  ~ ., data = air_train)
#summary(datalm)

pred_lm = predict(datalm, newdata = air_test)

test_y = air_test[, 3]

#���� : MSE, MAE, RMSE
lm_mse = mean((exp(test_y) - exp(pred_lm))^2)
lm_mae = caret::MAE(exp(test_y), exp(pred_lm))
lm_rmse = caret::RMSE(exp(test_y), exp(pred_lm))

#��� : R-squared, MSE, MAE, RMSE
cat(lm_rmse, lm_mae, lm_mse)
summary(datalm)

######################################## ������

#setwd('C:/weather')
rm(list=ls())

data <- read.csv('������final.csv')
#data$date <- as.Date(data$date)
data$sex <- as.factor(data$sex)
data$age <- as.factor(data$age)
data$weekday <- as.factor(data$weekday)
#data$month <- as.factor(data$month)
#data$season <- as.factor(data$season)
str(data)
data <- data[c(-1,-7,-15)]

set.seed(1)
idx<-createDataPartition(data$total_qty, p=0.7, list=F)

air_train<-data[idx, ]
air_test<-data[-idx, ]

datalm <- lm(total_qty  ~ ., data = air_train)
#summary(datalm)

pred_lm = predict(datalm, newdata = air_test)

test_y = air_test[, 3]

#���� : MSE, MAE, RMSE
lm_mse = mean((exp(test_y) - exp(pred_lm))^2)
lm_mae = caret::MAE(exp(test_y), exp(pred_lm))
lm_rmse = caret::RMSE(exp(test_y), exp(pred_lm))

#��� : R-squared, MSE, MAE, RMSE
cat(lm_rmse, lm_mae, lm_mse)
summary(datalm)


############################################################ test