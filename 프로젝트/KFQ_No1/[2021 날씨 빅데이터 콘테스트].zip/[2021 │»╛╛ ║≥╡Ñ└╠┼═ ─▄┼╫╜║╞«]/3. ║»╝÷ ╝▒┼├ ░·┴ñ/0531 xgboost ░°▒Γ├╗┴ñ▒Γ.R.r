setwd('C:/weather')
rm(list=ls())
library(dplyr)
library(ggplot2)
library(readxl)
library(randomForest)
library(car)
library(gridExtra)
library(DiagrammeR)
library(dummies)
library(xgboost)
library(caret)

elect <- read.csv('����û����final.csv')

#elect$date <- as.Date(elect$date)
elect$sex <- as.factor(elect$sex)
elect$age <- as.factor(elect$age)

elect$weekday <- as.factor(elect$weekday)
elect$season <- as.factor(elect$season)

t <- elect[c(-1,-10,-11,-15)]

# �׸�
t <- elect[c(-1,-15)]

set.seed(123)

str(t)

tmp <- t[, c(1,2,12,13)]
# �׸�
tmp <- t[, c(1,2,14,15)]
tmp1 <- dummy.data.frame(tmp)

d <- data.frame(t[, c(3:11)], tmp1)
# �׸�
d <- data.frame(t[,c(3:13)], tmp1)

m <- as.matrix(d)

idx <- sample(1:nrow(t), size = 0.75 * nrow(t))
train <- m[idx,]
test <- m[-idx,]

#elect$X[-idx]

m1_xgb <-
  xgboost(
    data = train[, 2:29], #���� 27, �׸� 29
    label = train[, 1],
    nrounds = 50,
    objective = "reg:squarederror",
    #objective = "reg:linear",
    eval_metric="rmse",
    early_stopping_rounds = 3,
    max_depth = 5,
    eta = .28
  )

#c2 <- chisq.test(t[c(idx),]$age, train[,1])

pred_xgb <- predict(m1_xgb, test[, 2:27])
# �׸�
pred_xgb <- predict(m1_xgb, test[, 2:29])

yhat <- pred_xgb
y <- test[, 1]
postResample(exp(yhat), exp(y))
postResample(yhat, y)  ##       RMSE   Rsquared        MAE 
##  12.2827652  0.8654008  7.0000327 



#########3 ���� �׸� �׸����
imp = xgb.importance(model = m1_xgb)
imp
xgb.plot.importance(imp)

data.frame(variable = rep(imp$Feature,1),
           value = c(imp$Gain),
           Type = c(rep('Gain',nrow(imp)))
) %>% ggplot(aes(variable,value,fill = variable))+
  geom_bar(stat = 'identity')+
  facet_grid(~Type)+
  theme_bw()+
  ggtitle('XGBoost : Importance Plot') + xlab('') + ylab('') + coord_flip()






par(mfrow=c(1,1), mar=c(3,3,3,3))
r <- y - yhat
plot(r, ylab = "residuals", main = "extreme gradient boosting")

plot(y,
     yhat,
     xlab = "actual",
     ylab = "predicted",
     main = "extreme gradient boosting")

abline(lm(yhat ~ y))

#plot first 3 trees of model
xgb.plot.tree(model = m1_xgb, trees = 0:2)

importance_matrix <- xgb.importance(model = m1_xgb)
xgb.plot.importance(importance_matrix, xlab = "Feature Importance")

sum(importance_matrix$Frequency[1:13])

################# hyperparameter tuning
#grid search
#create hyperparameter grid
hyper_grid <- expand.grid(max_depth = seq(2, 6, 1),
                          eta = seq(.05, .3, .01))
xgb_train_rmse <- NULL
xgb_test_rmse <- NULL

for (j in 1:nrow(hyper_grid)) {
  set.seed(123)
  m_xgb_untuned <- xgb.cv(
    data = train[, 2:27],
    label = train[, 1],
    nrounds = 50,
    objective = "reg:squarederror",
    eval_metric="rmse",
    early_stopping_rounds = 3,
    nfold = 5,
    max_depth = hyper_grid$max_depth[j],
    eta = hyper_grid$eta[j]
  )
  
  xgb_train_rmse[j] <- m_xgb_untuned$evaluation_log$train_rmse_mean[m_xgb_untuned$best_iteration]
  xgb_test_rmse[j] <- m_xgb_untuned$evaluation_log$test_rmse_mean[m_xgb_untuned$best_iteration]
  
  cat(j, "\n")
}

#ideal hyperparamters
hyper_grid[which.min(xgb_test_rmse), ]

ggplot(data = a, aes(x = c(1:130), y = xgb_test_rmse)) + geom_smooth() + xlab('')



##### 

m1_xgb <-
  xgboost(
    data = train[, 2:27],
    label = train[, 1],
    nrounds = 10,
    objective = "reg:squarederror",
    early_stopping_rounds = 3,
    max_depth = 6,
    eta = .29
  )

pred_xgb <- predict(m1_xgb, test[, 2:25])

yhat <- pred_xgb
y <- test[, 1]
postResample(yhat, y) ##       RMSE   Rsquared        MAE 
##  12.0744573  0.8696557  6.9557786 


### �׸�

r <- y - yhat
plot(r, ylab = "residuals", main = "extreme gradient boosting")

plot(y,
     yhat,
     xlab = "actual",
     ylab = "predicted",
     main = "extreme gradient boosting")

abline(lm(yhat ~ y))

#plot first 3 trees of model
xgb.plot.tree(model = m1_xgb, trees = 0:2)

importance_matrix <- xgb.importance(model = m1_xgb)
xgb.plot.importance(importance_matrix, xlab = "Feature Importance")





x = 1:length(y)
plot(x, y, col = "red", type = "l")
lines(x, pred_xgb, col = "blue", type = "l")
legend(x = 1, y = 250,  legend = c("original test_y", "predicted test_y"), 
       col = c("red", "blue"), box.lty = 1, cex = 0.8, lty = c(1, 1))

