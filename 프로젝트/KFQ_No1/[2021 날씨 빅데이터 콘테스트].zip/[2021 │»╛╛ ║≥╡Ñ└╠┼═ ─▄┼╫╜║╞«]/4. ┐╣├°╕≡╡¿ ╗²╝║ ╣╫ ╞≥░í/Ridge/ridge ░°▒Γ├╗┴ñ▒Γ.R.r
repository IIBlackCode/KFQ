setwd('C:/weather')
rm(list=ls())
library(caret)
#install.packages("glmnet")
library(glmnet)

set.seed(1)
aircon <- read.csv('����û����final.csv')
aircon <- aircon[c(-1,-13)]
aircon$age <- as.factor(aircon$age)
aircon$sex <- as.factor(aircon$sex)
aircon$weekday <- as.factor(aircon$weekday)
aircon$season <- as.factor(aircon$season)
str(aircon)

train <- createDataPartition(aircon$total_qty, p=0.7, list=F)

aircon_train <- aircon[train,]
aircon_test <- aircon[-train,]

x <- model.matrix(total_qty~ .,aircon_train)
y <- aircon_train$total_qty

ridge1 <- cv.glmnet(x=x,y=y, family="gaussian", alpha=0)
plot(ridge1)

ridge2 <- glmnet(x,y,family = "gaussian",alpha=0, lambda = ridge1$lambda.min)
coef(ridge2)

x <- model.matrix(total_qty~ .,aircon_test)
y <- predict(ridge2, newx=x)
postResample(pred=exp(y), obs=exp(aircon_test$total_qty))
